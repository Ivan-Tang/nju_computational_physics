# -*- coding: utf-8 -*- 
import matplotlib.pylab as pl
# -------------------- read in temperature and energy--------------------
temperature = []
energy=[]
with open('Etot-Temp.dat', 'r') as fin:
     for lines in fin:
         words = lines.split()
         T = float(words[0])
         E = float(words[1])
         temperature.append(T)
         energy.append(E)
n = len(temperature)
Cv=[0]*n
for i in range(1,n-1):
    Cv[i] = (energy[i+1] - energy[i-1])/(temperature[i+1] - temperature[i-1])

fig, ax = pl.subplots(nrows = 2, ncols = 1)

ax[0].plot(temperature, energy, marker='o',color='k', linewidth=2.0, label='Energy')
ax[1].plot(temperature, Cv, color='b', linewidth=2.0,label='Cv')

ax[0].set_xlim((300, 400))
ax[0].set_ylim((-110., -5.))
ax[1].set_xlim((300, 400))
ax[1].set_ylim((0., 4.))

ax[0].legend(loc='upper left')
ax[1].legend(loc='upper left')

ax[1].set_xlabel(r'Temperature(K)', fontsize=20)
ax[0].set_ylabel(r'E(kcal/mol)', fontsize=20)
ax[1].set_ylabel(r'Cv', fontsize=20)
pl.show()


#ax[0].set_xticks([300 + i * 10 for i in range(11)])
#ax[1].set_xticks([300 + i * 10 for i in range(11)])
#ax[0].set_yticks([-110 + i * 20 for i in range(6)])
#ax[1].set_yticks([0 + i * 1.0 for i in range(5)])