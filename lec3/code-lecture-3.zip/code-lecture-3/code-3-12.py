# -*- coding: utf-8 -*-
import numpy as np
import pylab as pl

g=9.8
xl=9.8
q = 0.5
W=2.0/3.0
dt=0.01
n = 10000
twopi = np.arctan(1.0)*8.0

ThetaT0 = []
OmigaT0 = []
F0 = []
for F in np.arange(0.5,2.0,0.01):
    theta=0.1
    omiga=0.1
    t=0.0
    for i in range(n):
        xk1=-(g/xl)*np.sin(theta)-q*omiga+F*np.sin(W*t)
        xl1=omiga
        xk2=-(g/xl)*np.sin(theta+dt/2.*xl1)-q*(omiga+dt/2.*xk1)+F*np.sin(W*(t+dt/2))
        xl2=omiga+dt/2.*xk1
        xk3=-(g/xl)*np.sin(theta+dt/2.*xl2)-q*(omiga+dt/2.*xk2)+F*np.sin(W*(t+dt/2))
        xl3=omiga+dt/2.*xk2
        xk4=-(g/xl)*np.sin(theta+dt*xl3)-q*(omiga+dt*xk3)+F*np.sin(W*(t+dt))
        xl4=omiga+dt*xk3

        omiga=omiga+dt/6.*(xk1+2*xk2+2*xk3+xk4)
        theta=theta+dt/6.*(xl1+2*xl2+2*xl3+xl4)

        if(theta > 3.1415927):
            theta=theta-3.1415927*2.
        if(theta < -3.1415927):
            theta=theta+3.1415927*2.
        t=t+dt

        if abs(W*t/twopi-int(W*t/twopi+1.0e-6))<0.005 and t>100:
            ThetaT0.append(theta)
            OmigaT0.append(omiga)
            F0.append(F)

fig = pl.figure(figsize=(8,5))
pl.plot(F0, ThetaT0, 'r.', label='F=0.0',ms=3.0)

pl.ylabel(r'Theta', fontsize=20)
pl.xlabel(r'F', fontsize=20)
pl.show()
