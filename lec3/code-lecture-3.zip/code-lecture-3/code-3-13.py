import numpy as np
import pylab as pl
from scipy.integrate import odeint

g=9.8
xl=9.8
q = 0.5
W=2.0/3.0
dt=0.1
n = 10000
twopi = np.arctan(1.0)*8.0

ThetaT0 = []
OmigaT0 = []
F0 = []

def pendulum(y, t) :
    f1 = -(g/xl)*np.sin(y[1])-q*y[0]+F*np.sin(W*t)
    f2 = y[0]
    return np.array([f1, f2])

#answer = odeint(pendulum, initialstate, time )
#answer = answer[100:]

time = np.arange(0,10000,0.01)
for F in np.arange(0.5,2.0,0.01):
    theta0=0.1
    omiga0=0.1
    traj = odeint(pendulum, (omiga0,theta0), time)

    i = 0
    for theta in traj[:,0]:
        theta_twopi = theta - np.floor((theta+twopi/2)/twopi)*twopi-twopi/2 
        t = time[i]
        if abs(W*t/twopi-int(W*t/twopi+1.0e-6))<0.005 and t>100:
            ThetaT0.append(theta_twopi)
            F0.append(F)
        i = i + 1
    
fig = pl.figure(figsize=(8,5))
pl.plot(F0, ThetaT0, 'r.', label='F=0.0',ms=5.0)

pl.ylabel(r'Theta', fontsize=20)
pl.xlabel(r'F', fontsize=20)
#pl.xlim(0.5,2.2)
#pl.ylim(-4.0,4.0)
#pl.show()
