# -*- coding: utf-8 -*-
import matplotlib.pylab as pl

time = []
xlist = []
ylist = []

istep=0
with open ('walk-traj.dat', 'r') as infile:
     for lines in infile:
         words=lines.split()
         time.append(int(words[0]))
         xlist.append(float(words[1]))
         ylist.append(float(words[2]))
         istep = istep + 1
nstep = istep

print("the maximal number of walk steps is:", nstep)
pl.plot(xlist[:], ylist[:],'r-',lw=1) #visualization
pl.xlabel('x-axis')
pl.ylabel('y-axis')
pl.show()

