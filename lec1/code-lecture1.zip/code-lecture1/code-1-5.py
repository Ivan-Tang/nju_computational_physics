# -*- coding: utf-8 -*-
"""
random walk
@author: wfli
"""

import numpy as np
import random

outfile = open('walk-traj.dat', 'w')

line = input("input the maximal nubmer of walk steps:")
nstep = int(line)
print("the maximal number of walk steps is:", nstep)

if nstep > 10000:
    print('too many steps')
    exit()
elif nstep <10:
    print('too few steps')
    exit()

x = 0.0
y = 0.0

random.seed(913) #ramdom number seed.
for i in range(nstep):
    dx = 2*random.random()-1 # random number(-1.0,1.0)
    dy = 2*random.random()-1

    dr = np.sqrt(dx**2+dy**2) 
    dx = dx/dr #normalization
    dy = dy/dr

    x = x + dx # updating x position 
    y = y + dy  

    outfile.write('%d\t%.2f\t%.2f\n' %(i, x, y))

outfile.close()
