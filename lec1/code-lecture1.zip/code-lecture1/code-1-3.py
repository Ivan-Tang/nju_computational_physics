# -*- coding: utf-8 -*-
"""
random walk
@author: wfli
"""

import numpy as np
import random

outfile = open('walk-traj.dat', 'w')

line = input("input the maximal nubmer of walk steps:")
nstep = int(line)

print("the maximal number of walk steps is:", nstep)

x = 0.0
y = 0.0

random.seed(913) #ramdom number seed.
for i in range(nstep):
    theta = random.random()*2*3.1415927
    dx = np.cos(theta)
    dy = np.sin(theta)

    x = x + dx # updating x position 
    y = y + dy  

    outfile.write('%d\t%.2f\t%.2f\n' %(i, x, y))

outfile.close()
