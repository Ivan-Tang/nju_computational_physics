# -*- coding: utf-8 -*-
"""
random walk
@author: wfli
"""
import numpy as np
import matplotlib.pylab as pl
import random
from scipy.optimize import leastsq

nwalker = 50000
nstep = 100

time = np.arange(nstep)
xr = np.zeros(nwalker)
yr = np.zeros(nwalker)
r = np.zeros(nwalker)
sum_walk = np.zeros(nstep) # mean square distance
y_fit = np.zeros(nstep)
p0 = np.zeros(2)

for iwalk in range(nwalker):
    random.seed(None)
    x = 0.0
    y = 0.0
    r2 = 0.0
    for istep in range(nstep):
        sum_walk[istep] = sum_walk[istep] + r2
        theta = random.random()*2*3.1415927
        dx = np.cos(theta)
        dy = np.sin(theta)
        x = x + dx
        y = y + dy
        r2 = x**2 + y**2

    xr[iwalk] = x
    yr[iwalk] = y
    r[iwalk] = np.sqrt(x**2+y**2)

for istep in range(nstep):
    sum_walk[istep] = sum_walk[istep]/nwalker # mean square distance

xprob, xedge = np.histogram(xr,bins = 20,normed=True)
yprob, yedge = np.histogram(yr,bins = 20,normed=True)
rprob, redge = np.histogram(r,bins = 20,normed=True)

xx = 0.5*(xedge[0:-1]+xedge[1:])
yy = 0.5*(yedge[0:-1]+yedge[1:])
rr = 0.5*(redge[0:-1]+redge[1:])

#-------------------------------------
def func(x, p):
    a0 = p[0]
    alpha0 = p[1]
    return a0*pow(x,alpha0)
def residuals(p, y, x):
    return y - func(x, p)
#-------------------------------------
p0[0] = 1.0
p0[1] = 1.0
parameters = leastsq(residuals, p0,args=(time,sum_walk))
print(parameters[0][0],parameters[0][1])
for i in np.arange(nstep):
   y_fit[i] = parameters[0][0]*np.power(time[i],parameters[0][1])
#-------------------------------------
fig = pl.figure(figsize=(7,7))
ax1 =fig.add_subplot(2,2,1)
ax2 =fig.add_subplot(2,2,2)
ax3 =fig.add_subplot(2,2,3)
ax4 =fig.add_subplot(2,2,4)

pl.subplots_adjust(left=0.15,bottom=0.1,top=0.9,right=0.95, \
                   hspace=0.25,wspace=0.3)

ax1.plot(time[::2],sum_walk[::2],'ro',fillstyle='none', \
         lw=1.0,label='data')
ax1.plot(time,y_fit, 'b-', linewidth=2.0, label='fitting')

ax2.plot(rr, rprob, 'm-',linewidth=2.0)
ax3.plot(xx, xprob, 'b-', linewidth=2.0)
ax4.plot(yy, yprob, 'k-', linewidth=2.0)

ax1.set_xlabel(r'time',fontsize=15)
ax1.set_ylabel(r'$<r^2>$',fontsize=15)
ax2.set_xlabel(r'r', fontsize=15)
ax2.set_ylabel(r'distribution', fontsize=15)
ax3.set_xlabel(r'x', fontsize=15)
ax3.set_ylabel(r'distribution', fontsize=15)
ax4.set_xlabel(r'y', fontsize=15)
ax4.set_ylabel(r'distribution', fontsize=15)

ax1.set_xlim(0,100)
ax1.set_ylim(0,120)
ax2.set_xlim(0,30)
ax2.set_ylim(0,0.1)
ax3.set_xlim(-30,30)
ax3.set_ylim(0,0.1)
ax4.set_xlim(-30,30)
ax4.set_ylim(0,0.1)
ax1.legend(loc='upper left',fontsize=15)
pl.show()


#pl.savefig('fig-1-2.png',bbox_inches='tight')
