# -*- coding: utf-8 -*-
import matplotlib.animation as animation
import numpy as np
import pylab as pl

PI=3.1415927
h=0.02
v=1
tau=0.2
A=v*h/tau
NX = 50
NT = 4000
Y = np.zeros([NX+1,NT+1],dtype=float)
Time = np.arange(0,NT+1,1)
X = np.arange(0,(NX+1)*h,h)

for i in np.arange(NX+1): #初始条件
#    Y[i,0]=np.sin(PI*h*i) #y(x,t) = sin(pix)
    Y[i,0]=np.sin(2*PI*h*i) #y(x,t) = sin(2pix)
    Y[i,1]= Y[i,0] #dy(x,t)/dt=0.0
for k in range(NT+1): #边界条件
    Y[0,k]=0.0
    Y[NX,k]=0.0

for k in range(1,NT):
    for i in range(1,NX):
        Y[i,k+1]=2.0*(1-A**2)*Y[i,k]+A**2*(Y[i+1,k]+Y[i-1,k])-Y[i,k-1]

def animate(i):
    line.set_ydata(Y[:,i])  # update the data.
    return line,

def update_line(num, X,Y,line):
    line.set_data(X[num],Y[num])
    return line,

fig1 = pl.figure()
line, = pl.plot(X, Y[:,0], 'r-',lw=2.0)
pl.xlim(0, 1)
pl.ylim(-2, 2)
pl.xlabel('X')
pl.ylabel('Y')
pl.title('String')
ani = animation.FuncAnimation(
    fig1, animate, interval=1, blit=False, save_count=50)

#dot_ani.save('Brownian.mp4',fps=30)
pl.show()

